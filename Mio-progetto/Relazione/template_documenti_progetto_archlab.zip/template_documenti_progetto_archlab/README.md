# Template per il Laboratorio di Architetture

Questo template LaTeX è da utilizzare per la consegna dei documenti di specifica e relazione per i corsi di laboratorio di Architetture degli Elaboratori I e II.

Alcune info utili:

* breve introduzione a LaTeX: http://www.cs.princeton.edu/courses/archive/spr10/cos433/Latex/latex-guide.pdf

* per la compilazione di questi sorgenti è consigliato l'uso di pdflatex.

Si ricorda la convenzione per il nome del file da inviare.

* Architetture 1 (specifica): <cognome>_<nome>_<matricola>_arch1lab_specifica.pdf

* Architetture 1 (relazione): <cognome>_<nome>_<matricola>_arch1lab_relazione.pdf

* Architetture 2 (specifica): <cognome>_<nome>_<matricola>_arch2lab_specifica.pdf